const CheeseburgerMenu = require('./dist/index');

module.exports = CheeseburgerMenu;
